# Calibration notes

Reference localization was provided by the lab-maintained `ws_localization` FAST-LIO/global_reloc stack using the onboard Livox MID360.

For this delivery, `/Odometry` was used as the reference pose source and interpreted as `map -> base_link`. The operator confirmed that `base_link` represents the Go2 base pose rather than the raw MID360 sensor frame.

No separate motion-capture calibration was used. No post-processing extrinsic correction was applied in `go2_plan_capture_runner.py`; the exported `pose_x`, `pose_y`, and `pose_yaw` are directly from `/Odometry` pose samples.

Known limitation: a full independent measurement report for the MID360-to-Go2-base mounting transform was not recorded. This should be improved in future formal 50 Hz or publication-bound captures.
