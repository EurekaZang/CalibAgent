# P1 Go2 Real Delivery

This directory contains a Unitree Go2 real-robot P1 capture collected on 2026-07-22 in 教学实验楼一楼大厅 on tile floor.

## Capture summary

- Robot: Unitree Go2
- Reference sensor: Livox MID360 using `ws_localization` FAST-LIO/global_reloc
- Reference topic: `/Odometry` (`map -> base_link`)
- Control bridge: `ws_fastlio` `go2_cmd_vel`
- Capture runner: `/home/unitree/lly/go2_plan_capture_runner.py`
- Capture plan: frozen `plan.csv`
- Sessions: `go2-session-01`, `go2-session-02`, `go2-session-03`
- Selected trials: 183 / 183
- Collection mode: approved 20 Hz LiDAR odometry mode
- Full rosbag recorded: no
- External video recorded: no

## Directory contents

- `capture_plan/`: frozen plan and manifest.
- `exported/go2_raw_trials.csv`: final selected measure-window pose samples.
- `metadata/trial_ledger.csv`: attempt ledger including the rejected attempt for `go2-session-03` trial 25.
- `metadata/trial_velocity_summary.csv`: quick velocity summary estimated from pose samples.
- `metadata/session_metadata.csv`: session-level metadata.
- `metadata/coordinate_frames.md`: coordinate convention and frame interpretation.
- `metadata/time_sync.md`: time-base notes.
- `calibration/`: reference-to-base transform notes.
- `raw/`: per-trial reference-native CSV exports from the capture runner.
- `checksums.sha256`: SHA-256 checksums for delivered files.

## Known limitations

This dataset was collected at approximately 20 Hz rather than the original 50 Hz target. The 20 Hz mode was approved before finalizing this delivery. No full ROS bag was recorded; only runner-exported per-trial raw/reference CSV files and final selected CSV are included.
