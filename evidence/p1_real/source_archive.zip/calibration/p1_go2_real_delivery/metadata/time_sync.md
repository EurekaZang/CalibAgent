# Time synchronization

All capture-relevant ROS2 nodes were run on the onboard Go2/Jetson environment using the same ROS2/system time base:

- `ws_localization` published `/Odometry` and `/loc_health`.
- `ws_fastlio` `go2_cmd_vel` bridge published `/go2_capture/actual_cmd_vel`.
- `/home/unitree/lly/go2_plan_capture_runner.py` published `/cmd_vel` and recorded measure-window samples.

The final CSV `timestamp` values come from the `/Odometry` message timestamp. Actual command values were read from `/go2_capture/actual_cmd_vel`. No cross-machine clock mapping, external NTP/PTP correction, or post-hoc timestamp shifting was applied.

This dataset was collected in the approved 20 Hz mode. The observed `/Odometry` frequency was approximately 20 Hz during accepted trials, with max timestamp gaps below 0.10 s in the final selected data.
