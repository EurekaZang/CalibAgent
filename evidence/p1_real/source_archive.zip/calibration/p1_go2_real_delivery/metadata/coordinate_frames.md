# Coordinate frames

- Robot: Unitree Go2.
- Reference source: Livox MID360 with `ws_localization` FAST-LIO/global_reloc localization stack.
- Reference topic used by the capture runner: `/Odometry`.
- `/Odometry` was treated as `map -> base_link`.
- `base_link` was treated as the Go2 base frame.
- Final CSV fields `pose_x`, `pose_y`, and `pose_yaw` are interpreted as Go2 base SE(2) pose in the map frame.

## Axis convention

- `+x`: forward in Go2 base frame.
- `+y`: left in Go2 base frame.
- `+z`: up.
- `+cmd_wz` / `+pose_yaw`: counter-clockwise yaw about base z.

## Notes

The operator confirmed during collection that the localization output represented the Go2 pose, not the raw MID360 sensor pose. No post-hoc per-trial sign flipping or pose editing was applied.
